DROP INDEX [idx_tag_name] ON [#__contentitem_tag_map];
DROP INDEX [idx_tag] ON [#__contentitem_tag_map];
DROP INDEX [idx_type] ON [#__contentitem_tag_map];
